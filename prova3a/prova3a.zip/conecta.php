<?php
$conexao = new mysqli('localhost', 'root', 'ifsp', 'cadastro');